function OpenScope

%oscmx(0);
oscmx(2);
oscmx(4);
