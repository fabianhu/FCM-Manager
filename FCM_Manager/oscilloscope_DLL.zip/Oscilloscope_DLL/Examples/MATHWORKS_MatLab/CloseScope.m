function CloseScope

oscmx(3);
%oscmx(-1);
clear oscmx

