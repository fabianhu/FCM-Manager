OpenScope - open the scope
CloseScope - close the scope

junk_scope - example of run from main tread

junk_start_timer - example of run from timer (>= MATLAB 6)
cbMyTimer - the timer callback


The dll is unloaded automatically by 
clear functions or
clear OscMx

or exit from MATLAB.


It is tested with Matlab versions up to 2006b
